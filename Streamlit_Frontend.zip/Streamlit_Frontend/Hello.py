import streamlit as st

# Set the page configuration first
st.set_page_config(
    page_title="Welcome to HealthGeek",
    page_icon="👋",
)

# Add custom CSS to set the background color
st.markdown(
    """
    <style>
    body {
        background-color: #808080; /* Use your preferred shade of grey */
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.write("# Welcome to HealthGeek's \n # Diet Recommendation System! 👋")

st.sidebar.success("Select a recommendation app.")

st.markdown(
    """
    A diet recommendation web application using a content-based approach.
    """
)
